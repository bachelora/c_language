//
//  DayDetailViewController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/8/3.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "DayDetailViewController.h"
@import Masonry;
@interface DayDetailViewController ()
@property(nonatomic,strong)UIView *bkVIew;
@end

@implementation DayDetailViewController

-(void)loadURL:(NSString *)url{
    [super loadURL:url];
    NSLog(@"--%@",url);
}

-(void)loadView{
    [super loadView];
    self.view = self.bkVIew;
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    NSLog(@"didCommitNavigation");
    
   // [self webView:webView didFinishNavigation:navigation];
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    webView.hidden = YES;
}
-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
     NSString *js = @"var idObject = document.getElementsByClassName('box_top')[0]; \
        idObject.parentNode.removeChild(idObject);\
    \
        idObject = document.getElementsByClassName('ad_main')[0];\
        idObject.parentNode.removeChild(idObject);\
        $('.tk_main').next().remove();\
        idObject = document.getElementsByClassName('tk_main')[0];\
    idObject.parentNode.removeChild(idObject);\
    \
        idObject = document.getElementsByClassName('search_box clearfix')[0];\
        idObject.parentNode.removeChild(idObject);\
       \
         $('.m_q_btn.clearfix').remove();\
        idObject = document.getElementsByClassName('foo')[0].parentNode;\
        idObject.parentNode.removeChild(idObject);\
    \
    idObject = document.getElementsByClassName('tice_add')[0];\
    idObject.parentNode.removeChild(idObject);\
    \
    idObject = $('.m_q_btn.clearfix');\
    for(var i=0;i<idObject.length;i++){\
       $(idObject).remove();  \
    }\
    \
        idObject = document.getElementsByClassName('interviewed-div')[0];\
        idObject.parentNode.removeChild(idObject);";

        [webView evaluateJavaScript:js completionHandler:^(id _Nullable a, NSError * _Nullable error) {
            NSLog(@"-err--%@",error);
            webView.hidden = NO;
        }];//
}

-(UIView *)bkVIew{
    if (!_bkVIew) {
        _bkVIew = UIView.new;
         _bkVIew = [UIView.alloc initWithFrame:UIScreen.mainScreen.bounds];
        _bkVIew.backgroundColor = UIColor.whiteColor;
        UILabel*    _note = UILabel.new;
        _note.backgroundColor = UIColor.clearColor;
        _note.text = @"Pls Waiting...";
        _note.font = [UIFont fontWithName:@"PingFangSC-Medium" size:35];
        [_bkVIew addSubview:_note];
               
       UIActivityIndicatorView*  indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    indicator.color = UIColor.grayColor;
        [_bkVIew addSubview:indicator];
               [indicator mas_makeConstraints:^(MASConstraintMaker *make) {
                   make.centerX.equalTo(_bkVIew);
                   make.bottom.equalTo(_note.mas_top).offset(-0);
                   make.width.equalTo(@50);
                   make.height.equalTo(@50);
               }];
               [indicator startAnimating];
               
               [_note mas_makeConstraints:^(MASConstraintMaker *make) {
                   make.center.equalTo(_bkVIew);
               }];
    }
    return _bkVIew;
}

@end
