//
//  WKViewController.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

@import WebKit;
NS_ASSUME_NONNULL_BEGIN

@interface WKViewController : UIViewController{
@private
    WKWebView *_webView;
}
@property(nonatomic,strong,readonly)WKWebView*webView;
@property(nonatomic,copy)NSString *webURL;
-(void)loadURL:(NSString*)url;
@end

NS_ASSUME_NONNULL_END
