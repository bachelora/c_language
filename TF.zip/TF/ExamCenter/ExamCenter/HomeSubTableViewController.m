//
//  HomeSubTableViewController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "HomeSubTableViewController.h"
#import "HomeSubTableViewCell.h"
#import "ListController.h"
#import "NSObject+Request.h"

@interface HomeSubTableViewController ()
@property(nonatomic,strong)NSArray <NSString*>* indexs;
@property(nonatomic,strong)NSArray <NSArray<SubCategoryModel*>*>*array;
@end

@implementation HomeSubTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.model.name;
    NSMutableDictionary *dict = @{}.mutableCopy;
    for (SubCategoryModel*mod in self.model.subs) {
        NSMutableArray *arry = dict[mod.h];
        if (!arry) {
            arry = @[].mutableCopy;
            dict[mod.h] = arry;
        }
        [arry addObject:mod];
    }
    self.indexs = [dict.allKeys sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:nil ascending:YES]]];
    self.array = [dict.allValues sortedArrayUsingComparator:^NSComparisonResult(NSArray<SubCategoryModel*>* obj1,NSArray<SubCategoryModel*>* obj2) {
        return [obj1.firstObject.h compare:obj2.firstObject.h options:NSCaseInsensitiveSearch];
    }];;
    [self.tableView reloadData];
}

#pragma mark - Table view data source
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.array[section] firstObject].h;
}

-(NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    return  self.indexs;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.array.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array[section].count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeSubTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    SubCategoryModel *m = self.array[indexPath.section][indexPath.row];
    // Configure the cell...
    cell.name.text = m.name;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.Type == HomeTableTypeNormal) {
        [self performSegueWithIdentifier:@"push" sender:nil];
    }else{
        NSIndexPath *selected = indexPath;
        SubCategoryModel *m = self.array[selected.section][selected.row];
        
        [NSNotificationCenter.defaultCenter postNotificationName:@"changeDay" object:nil userInfo:@{@"url":m.url}];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ListController *list = segue.destinationViewController;
    NSIndexPath *selected = self.tableView.indexPathForSelectedRow;
    SubCategoryModel *m = self.array[selected.section][selected.row];
    list.url = m.url;
}


@end
