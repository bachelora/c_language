//
//  DayTableViewController.h
//  ExamCenter
//
//  Created by Mahoone on 2020/8/3.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DayTableViewCell.h"
NS_ASSUME_NONNULL_BEGIN

@interface DayTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
