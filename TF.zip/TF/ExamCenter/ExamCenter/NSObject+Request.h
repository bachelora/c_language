//
//  NSObject+Request.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//



#import <Foundation/Foundation.h>

@import WebKit;

typedef void(^WebViewDidFinishNavigation)(id _Nullable data);
typedef void(^WebViewDidFailNavigation)(WKWebView *webView,NSError *error);
NS_ASSUME_NONNULL_BEGIN


@interface NSObject (Request)

-(void)adfjasddsfa;
+(void)tjlkfad;

+(WKWebView*)loadUrl:(NSString*)url jsContent:(NSString*)jsContent success:(WebViewDidFinishNavigation)success failed:(WebViewDidFailNavigation)failed;
@end

NS_ASSUME_NONNULL_END
