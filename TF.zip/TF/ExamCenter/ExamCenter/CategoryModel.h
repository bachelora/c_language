//
//  CagegoryModel.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SubCategoryModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface CategoryModel : NSObject

@property(nonatomic,copy)NSString *name;
//@property(nonatomic,copy)NSString *url;
@property(nonatomic,copy)NSString *icon;

@property(nonatomic,strong)NSArray <SubCategoryModel*>*subs;

@end

NS_ASSUME_NONNULL_END
