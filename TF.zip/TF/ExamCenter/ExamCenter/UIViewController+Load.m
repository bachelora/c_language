//
//  UIViewController+Load.m
//  ExamCenter
//
//  Created by Mahoone on 2020/8/3.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "UIViewController+Load.h"

#define kBaseURL (@"https://raw.githubusercontent.com/bachelora/yyyyadf0803/master/")
@import AFNetworking;
@import YYModel;

@implementation UIViewController (Load)

+(void)loadApi:(NSString*)api class:(Class)class completionHandler:(nullable void (^)(NSArray* array,  NSError * _Nullable error))completionHandler{
    NSString *path = [NSString stringWithFormat:@"%@%@",kBaseURL,api];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFJSONResponseSerializer *ser = AFJSONResponseSerializer.serializer;;
    ser.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = ser;
    NSURL *URL = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        NSArray *ret = nil;
        if (!error) {
           ret= [NSArray yy_modelArrayWithClass:class json:responseObject];
        }
        if (completionHandler) {
            completionHandler(ret,error);
        }
    }];
    [dataTask resume];
}
@end
