//
//  ListModel.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListModel : NSObject
@property(nonatomic,copy)NSString*title;
@property(nonatomic,copy)NSString*url;
@property(nonatomic,copy)NSString*time;
@property(nonatomic,copy)NSString*source;
@end

NS_ASSUME_NONNULL_END
