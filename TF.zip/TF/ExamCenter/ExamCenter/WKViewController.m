//
//  WKViewController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "WKViewController.h"

@interface WKViewController ()<WKNavigationDelegate>

@end

@implementation WKViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)loadView{
    self.view = self.webView;
    [self loadURL:self.webURL];
}

-(WKWebView *)webView{
    if (_webView) {
        return _webView;
    }
    WKWebViewConfiguration *config = [WKWebViewConfiguration.alloc init];
    _webView = [WKWebView.alloc initWithFrame:UIScreen.mainScreen.bounds configuration:config];
    _webView.navigationDelegate = self;
    return _webView;
}



-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    NSLog(@"didCommitNavigation");
}
-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"didFailNavigation-%@",error);
}
-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
}
-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"didStartProvisionalNavigation");
}

-(void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"didFailProvisionalNavigation--%@",error);
}

-(void)loadURL:(NSString*)url{
    self.webURL = url;
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
}

@end
