//
//  DayModel.m
//  ExamCenter
//
//  Created by Mahoone on 2020/8/3.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "DayModel.h"

@implementation DayModel

@end
