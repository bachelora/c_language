//
//  NSObject+Request.m
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "NSObject+Request.h"



@interface ECWebView : WKWebView<WKNavigationDelegate,WKScriptMessageHandler>
@property(nonatomic,copy)WebViewDidFinishNavigation didFinish;
@property(nonatomic,copy)WebViewDidFailNavigation didFail;
@end


@implementation ECWebView
+(instancetype)instance:(NSString*)jsContent{
    NSString *jsFunction = [NSString stringWithFormat:@"function collectionData(){ %@ }",jsContent];
    WKUserScript *userScript = [[WKUserScript alloc]initWithSource:jsFunction injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:YES];
    WKUserContentController *controller = [[WKUserContentController alloc]init];
    [controller addUserScript:userScript];
    
    WKWebViewConfiguration *config = [WKWebViewConfiguration.alloc init];
    config.userContentController = controller;
    ECWebView *web = [ECWebView.alloc initWithFrame:UIScreen.mainScreen.bounds configuration:config];
    [web.configuration.userContentController addScriptMessageHandler:web name:@"jsCallObjectC"];
    web.navigationDelegate = web;
    return web;
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"didStartProvisionalNavigation");
}
-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    NSLog(@"didCommitNavigation");
    dispatch_after(2, dispatch_get_main_queue(), ^{
        [self collection:webView];
    });
}
-(void)webViewWebContentProcessDidTerminate:(WKWebView *)webView{
    NSLog(@"webViewWebContentProcessDidTerminate");
}
-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSLog(@"decidePolicyForNavigationAction");
    decisionHandler(WKNavigationActionPolicyAllow);
}
-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    if (self.didFail) {
        self.didFail(webView, error);
    }
    NSLog(@"didFailNavigation-error-%@",error);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    NSLog(@"-didFinishNavigation-");
    [self collection:webView];
}

-(void)collection:(WKWebView*)webView{
    [webView evaluateJavaScript:@"collectionData();" completionHandler:^(id _Nullable a, NSError * _Nullable error) {
           if (error && self.didFail) {
               self.didFail(webView, error);
           }
          NSLog(@"evaluateJavaScript--%@",error);
       }];
}

- (void)userContentController:(nonnull WKUserContentController *)userContentController didReceiveScriptMessage:(nonnull WKScriptMessage *)message {
    if ([message.name isEqualToString:@"jsCallObjectC"]) {
        if (self.didFinish) {
            self.didFinish(message.body);
        }
    }
    NSData *json = [NSJSONSerialization dataWithJSONObject:message.body options:NSJSONWritingPrettyPrinted error:nil];
    NSString *str = [NSString.alloc initWithData:json encoding:NSUTF8StringEncoding];
    NSLog(@"body:%@",str);
}

@end

@implementation NSObject (Request)
- (void)adfjasddsfa{
    NSLog(@"--%s",__func__);
}
+ (void)tjlkfad{
    NSLog(@"--%s",__func__);
}

+(WKWebView*)loadUrl:(NSString*)url jsContent:(NSString*)jsContent success:(WebViewDidFinishNavigation)success failed:(WebViewDidFailNavigation)failed{
    ECWebView *web = [ECWebView instance:jsContent];

    NSLog(@"--url=%@",url);
    web.didFinish = success;
    web.didFail = failed;
    [web stopLoading];
    [web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    return web;
}

@end
