//
//  DayTableViewController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/8/3.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "DayTableViewController.h"
#import "DayModel.h"
#import "NSObject+Request.h"
#import "DayDetailViewController.h"
#import "UIViewController+Load.h"
#import "HomeTableViewController.h"

@import YYModel;
@interface DayTableViewController ()
{
    WKWebView *webView;
}
@property(nonatomic,strong)NSArray<DayModel*> *array;
@end

@implementation DayTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [UIViewController loadApi:@"day.json" class:DayModel.class completionHandler:^(NSArray * _Nonnull array, NSError * _Nullable error) {
        if (!error) {
            self.array = array;
            [self.tableView reloadData];
        }
    }];
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(notifacation:) name:@"changeDay" object:nil];
}

-(void)notifacation:(NSNotification*)n{

    NSString *url = n.userInfo[@"url"];
    NSLog(@"receive--%@",url);
    
    if (url.length) {
        url = [url stringByAppendingPathComponent:@"day"];
        
        [self loadURl:url];
    }
    
}

-(void)loadURl:(NSString*)url{

    NSString *js = @"\
       var boxs = $('.day-list a.sj_item.clearfix'); \
       var array = new Array();       \
       $.each(boxs,function(index,value){\
           var dict = {};\
           dict['url'] = $(value).attr('href');\
           var spans = $('span',$(value));\
           dict['title']= $('span p',$(value)).text();\
           dict['time'] = $('span i',$(value)).text();\
           array[index] = dict;\
       });\
       window.webkit.messageHandlers.jsCallObjectC.postMessage(array);";
    if (webView) {
        [webView stopLoading];
    }
    webView =
    [NSObject loadUrl:url jsContent:js success:^(NSArray* data) {
        if (data.count == 0) {
            return ;
        }
        self.array = [NSArray yy_modelArrayWithClass:DayModel.class json:data];
        [self.tableView reloadData];
    } failed:^(WKWebView *webView, NSError *error) {
        
    }];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DayTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    cell.button.layer.cornerRadius = 5;
    cell.button.clipsToBounds = YES;
    DayModel *m = self.array[indexPath.row];
    cell.title.text = m.title;
    cell.time.text = m.time;
    return cell;
}




#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DayDetailViewController *detail = segue.destinationViewController;
    if ([detail isKindOfClass:DayDetailViewController.class]) {
     
        DayModel *m = self.array[self.tableView.indexPathForSelectedRow.row];
        detail.webURL = m.url;
        detail.title = m.title;
        return;
    }
    
    HomeTableViewController *home = segue.destinationViewController;
    if ([home isKindOfClass:HomeTableViewController.class]) {
        home.hidesBottomBarWhenPushed = YES;
        home.title = @"请选择";
        home.Type = HomeTableTypePicker;
    }
}


@end
