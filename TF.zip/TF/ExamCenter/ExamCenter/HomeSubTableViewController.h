//
//  HomeSubTableViewController.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryModel.h"
#import "HomeTableViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface HomeSubTableViewController : UITableViewController
@property(nonatomic,strong)CategoryModel * model;

@property(nonatomic,assign)HomeTableType Type;
@end

NS_ASSUME_NONNULL_END
