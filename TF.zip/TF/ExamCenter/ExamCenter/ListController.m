//
//  ListController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "ListController.h"
#import "ListTableViewCell.h"
#import "NSObject+Request.h"
#import "ListModel.h"
#import "DetailViewController.h"

@import Masonry;
@import YYModel;
@interface ListController (){
    UIActivityIndicatorView *indicator;
}
@property(nonatomic,strong)NSArray <ListModel*>*data;
@property(nonatomic,strong)UILabel *note;
@property(nonatomic,strong)UIView *bkView;
@property(nonatomic,strong)WKWebView *webView;
@end

@implementation ListController

- (void)viewDidLoad {
    [super viewDidLoad];
   // self.url = @"https://m.ppkao.com/tiku/12343/";
    NSString *js = @"\
    var boxs = $('.recommend_box.recommend_bank_box > a.recommend_text_r'); \
    var array = new Array();       \
    $.each(boxs,function(index,value){\
        var dict = {};\
        dict['url'] = $(value).attr('href');  \
        $.each($('div.recommend_text > p',$(value)),function(id,val){\
           var str = $(val).text();\
           if(str.length > 0){\
                dict['title'] = str;\
                return false;\
            }\
         });\
        dict['source']= $('p.recommend_p2',$(value)).text();\
        dict['time'] = $('span.fr',$(value)).text();\
        array[index] = dict;\
    });\
    window.webkit.messageHandlers.jsCallObjectC.postMessage(array);";
    self.webView = 
    [NSObject loadUrl:self.url jsContent:js success:^(id obj) {
        self.data = [NSArray yy_modelArrayWithClass:ListModel.class json:obj];
        
        NSLog(@"success---%@",obj);
        if (self.data.count == 0) {
            self.note.text = @"No Data";
            [self->indicator stopAnimating];
        }
        [self.tableView reloadData];
    } failed:^(WKWebView *webView, NSError *error) {
        NSLog(@"err--%@",error);
    }];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    tableView.backgroundView = self.data.count?nil:self.bkView;
    return self.data.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    ListModel *m = self.data[indexPath.row];
    cell.title.text = m.title;
    cell.source.text = m.source;
    cell.time.text = m.time;
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DetailViewController *detail = segue.destinationViewController;
    ListModel *m = self.data[self.tableView.indexPathForSelectedRow.row];
    detail.webURL = m.url;
    detail.title = m.title;
}

-(UIView *)bkView{
    if (!_bkView) {
        _bkView = [UIView.alloc initWithFrame:UIScreen.mainScreen.bounds];
        _bkView.backgroundColor = UIColor.whiteColor;
        _note = UILabel.new;
        _note.backgroundColor = UIColor.clearColor;
        _note.text = @"Pls Waiting...";
        _note.font = [UIFont fontWithName:@"PingFangSC-Medium" size:35];
        [_bkView addSubview:_note];
        
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
        indicator.color = UIColor.grayColor;
        [_bkView addSubview:indicator];
        [indicator mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(_bkView);
            make.bottom.equalTo(_note.mas_top).offset(-0);
            make.width.equalTo(@50);
            make.height.equalTo(@50);
        }];
        [indicator startAnimating];
        
        [_note mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(_bkView);
        }];
    }
    return _bkView;
}

@end
