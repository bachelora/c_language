//
//  HomeTableViewController.m
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "HomeTableViewController.h"
#import "NSObject+Request.h"
#import "CategoryModel.h"
#import "HomeTableViewCell.h"
#import "HomeSubTableViewController.h"
#import "UIViewController+Load.h"


@import YYModel;

@interface HomeTableViewController ()
@property(nonatomic,strong)NSArray <CategoryModel*>*array;
@end

@implementation HomeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
    NSString *js = @"\
    var boxs = $('.parent_box'); \
    var array = new Array();       \
    $.each(boxs,function(index,value){\
        var dict = {};                        \
        dict['name'] = $('p',value).html();                       \
        var subs = new Array();     \
        var allLis = $('ul.clearfix > li',value);          \
        $.each(allLis,function(id,val){          \
            var span = $('span',$(val)).text();\
            $.each($('ul > li',$(val)),function(_id,_val){\
               var subDict = {};\
               var link=$('a',$(_val));\
               subDict['h'] =  span;\
               subDict['name'] =  link.text();\
               subDict['url'] =  link.attr('href');\
               subs.push(subDict);            \
            }); \
        }); \
        dict['subs'] = subs;                \
        array[index] = dict;                     \
    });                        \
    window.webkit.messageHandlers.jsCallObjectC.postMessage(array);";
    
    [NSObject loadUrl:@"https://m.ppkao.com/tiku/" jsContent:js success:^(id obj) {
        self.array = [NSArray yy_modelArrayWithClass:CategoryModel.class json:obj];
        [self.tableView reloadData];
        
    } failed:^(WKWebView *webView, NSError *error) {
        NSLog(@"err--%@",error);
    }];*/
    [UIViewController loadApi:@"cagegroy.json" class:CategoryModel.class completionHandler:^(NSArray * _Nonnull array, NSError * _Nullable error) {
        if (!error) {
            self.array = array;
            [self.tableView reloadData];
        }
    }];
    
}

#pragma mark - Table view data source

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    CategoryModel *m = self.array[indexPath.row];
    // Configure the cell...
   // UIButton*a;
    cell.name.text = m.name;
    cell.count.text = @(m.subs.count).stringValue;
    return cell;
}




#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    HomeSubTableViewController *table = segue.destinationViewController;
    CategoryModel * model = self.array[self.tableView.indexPathForSelectedRow.row];
    table.model = model;
    table.Type = self.Type;
}


@end
