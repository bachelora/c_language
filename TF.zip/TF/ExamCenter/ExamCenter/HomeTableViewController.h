//
//  HomeTableViewController.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, HomeTableType) {
    HomeTableTypeNormal = 0,
    HomeTableTypePicker = 1,
};

NS_ASSUME_NONNULL_BEGIN

@interface HomeTableViewController : UITableViewController

@property(nonatomic,assign)HomeTableType Type;

@end

NS_ASSUME_NONNULL_END
