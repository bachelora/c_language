//
//  MineeeeeViewController.m
//  ExamCenter
//
//  Created by mahoone on 2020/8/6.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "MineeeeeViewController.h"

@interface MineeeeeViewController ()

@end

@implementation MineeeeeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
       self.versionLable.text = version;
}



@end
