//
//  DetailViewController.h
//  ExamCenter
//
//  Created by Mahoone on 2020/7/30.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "WKViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : WKViewController

@end

NS_ASSUME_NONNULL_END
