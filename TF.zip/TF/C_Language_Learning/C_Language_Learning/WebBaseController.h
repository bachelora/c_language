//
//  WebBaseController.h
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
@import WebKit;
NS_ASSUME_NONNULL_BEGIN

@interface WebBaseController : UIViewController

@property(nonatomic,strong)NSURLRequest *request;

@property(nonatomic,strong)WKWebView *wkWebView;

@end

NS_ASSUME_NONNULL_END
