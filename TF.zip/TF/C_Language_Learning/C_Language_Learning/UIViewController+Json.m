//
//  UIViewController+Json.m
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "UIViewController+Json.h"
#import <objc/runtime.h>

#define kFullURL  (@"https://raw.githubusercontent.com/bachelora/c_language/master/")

@import YYModel;
@import AFNetworking;

@implementation UIViewController (Json)


- (YYCache *)cache{
    YYCache*cc =  objc_getAssociatedObject(self, @"cache");
    
    if (!cc) {
        NSString *name = NSStringFromClass(self.class);
        cc = [YYCache cacheWithName:name];
        objc_setAssociatedObject(self, @"cache", cc, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return cc;
}



-(NSString*)yytdsfjlka{
    for (int i=0; i<10; i++) {
        NSLog(@"乱写的代码。。。");
    }
    return @"dfasfasdfa";
}

-(int)aafdasfasdfasdf{
    for (int i=0; i<100; i++) {
           NSLog(@"乱写的代码。。。");
       }
    return 2+3;
}


+(void)getFrom:(NSString*)api model:(Class)class completion:(nullable void (^)(NSArray* array,  NSError * _Nullable error))completion{
    NSString *path = [NSString stringWithFormat:@"%@%@",kFullURL,api];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFJSONResponseSerializer *ser = AFJSONResponseSerializer.serializer;;
    ser.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = ser;
    NSURL *URL = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        NSArray *ret = nil;
        if (!error) {
           ret= [NSArray yy_modelArrayWithClass:class json:responseObject];
        }
        if (completion) {
            completion(ret,error);
        }
    }];
    [dataTask resume];
}

@end
