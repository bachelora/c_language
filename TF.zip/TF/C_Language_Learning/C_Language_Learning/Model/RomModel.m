//
//  RomModel.m
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "RomModel.h"

@import YYModel;

@implementation RomModel

-(instancetype)initWithCoder:(NSCoder *)coder{
//    [super init];
    return [self yy_modelInitWithCoder:coder];
}

-(void)encodeWithCoder:(NSCoder *)coder{
    [self yy_modelEncodeWithCoder:coder];
}

@end
