//
//  SectionModel.h
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RomModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface SectionModel : NSObject<NSCoding>

@property(nonatomic,copy)NSString *title;
@property(nonatomic,strong)NSArray<RomModel*> *array;
@end

NS_ASSUME_NONNULL_END
