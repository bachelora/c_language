//
//  RowTableViewController.h
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RomModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface RowTableViewController : UITableViewController
@property(nonatomic,strong)NSArray <RomModel*>*datasss;
@end

NS_ASSUME_NONNULL_END
