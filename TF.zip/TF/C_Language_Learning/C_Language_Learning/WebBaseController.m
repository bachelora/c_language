//
//  WebBaseController.m
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "WebBaseController.h"

@interface WebBaseController ()<WKNavigationDelegate>

@end

@implementation WebBaseController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)loadView{
    self.view = self.wkWebView;
    [self.wkWebView loadRequest:self.request];
}

-(WKWebView *)wkWebView{
    if (!_wkWebView) {
        WKWebViewConfiguration *c = [WKWebViewConfiguration.alloc init];
        _wkWebView = [WKWebView.alloc initWithFrame:UIScreen.mainScreen.bounds
                        configuration:c];
        _wkWebView.navigationDelegate = self;
    }
    return _wkWebView;;
}

#pragma mark - Delegate

//- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
//    NSLog(@"decidePolicyForNavigationAction");
//    decisionHandler(WKNavigationActionPolicyAllow);
//}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction preferences:(WKWebpagePreferences *)preferences decisionHandler:(void (^)(WKNavigationActionPolicy, WKWebpagePreferences *))decisionHandler{
    
    NSLog(@"decidePolicyForNavigationAction");
    
    WKWebpagePreferences *pre = [WKWebpagePreferences.alloc init];
    decisionHandler(WKNavigationActionPolicyAllow,pre);
}


- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    NSLog(@"decidePolicyForNavigationResponse");
    
    decisionHandler(WKNavigationResponsePolicyAllow);
}


- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"didStartProvisionalNavigation");
}


- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"didReceiveServerRedirectForProvisionalNavigation");
}


- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"didFailProvisionalNavigation---%@",error);
}


- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"didCommitNavigation");
}


- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"didFinishNavigation");
}


- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"didFailNavigation");
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * _Nullable credential))completionHandler{
    NSLog(@"didReceiveAuthenticationChallenge");
    
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling,nil);
}


- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView{
    NSLog(@"webViewWebContentProcessDidTerminate");
}

@end
