//
//  LearningViewController.m
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "LearningViewController.h"

@import Masonry;

@interface LearningViewController ()
@property(nonatomic,strong)UILabel *noteLable;
@property(nonatomic,strong)UIActivityIndicatorView *indicator;
@property(nonatomic,strong)UIView *bkView;
@end

@implementation LearningViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *refresh = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshWeb)];
    self.navigationItem.rightBarButtonItems = @[refresh];
}

-(void)refreshWeb{
    [self.wkWebView reload];
}

-(void)loadView{
    UIView *bk = UIView.new;
    bk.backgroundColor = UIColor.whiteColor;
    self.view = bk;
    [self.view addSubview:self.bkView];
    [self.bkView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
    [self.view addSubview:self.wkWebView];
    [self.wkWebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
     [self.wkWebView loadRequest:self.request];
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    webView.hidden = YES;
    self.bkView.hidden = NO;
//    self.bkView.backgroundColor = UIColor.redColor;
    self.noteLable.text = @"加载中...";
    [self.indicator startAnimating];
    NSLog(@"didStartProvisionalNavigation-%@",webView.URL);
}


- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"didFinishNavigation");
    
    NSString *js = @"\
        $('#header').remove();\
        $('.content_box.course_head').remove();\
        $('.position').next().children()[1].remove();\
        $('.position').remove();\
        $('.div_course_rand.content_r').remove(); \
        var all = $('.content_r.ueditor_container');\
        var children = all.children(); \
        for(var i=1;i<children.length;i++){\
          children[i].remove();\
         }\
        all.next().remove();\
        $('.col-xs-3.row_sidebar.row_sidebar_tutorial').remove();\
        $('.div_btn_opendrawer').remove(); \
        $('#footer').remove();$('a').remove(); \
        ;";

       [webView evaluateJavaScript:js completionHandler:^(id _Nullable a, NSError * _Nullable error) {
           NSLog(@"evaluateJavaScript--%@",error);
           self.bkView.hidden = YES;
           webView.hidden = NO;
       }];//
   
}

-(UIView *)bkView{
    if (!_bkView) {
        _bkView = UIView.new;
        _bkView.backgroundColor = UIColor.whiteColor;
        _noteLable = UILabel.new;
        _noteLable.text = @"加载中";
        _noteLable.textColor = UIColor.blackColor;
        _noteLable.font = [UIFont fontWithName:@"PingFangSC-Medium" size:30];
        [_bkView addSubview:_noteLable];
        [_noteLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(_bkView);
        }];
        
        _indicator = [UIActivityIndicatorView.alloc init];
        _indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleMedium;
        [_bkView addSubview:_indicator];
        [_indicator mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(_bkView);
            make.bottom.equalTo(_noteLable.mas_top).offset(-5);
        }];
    }
    return _bkView;;
}

@end
