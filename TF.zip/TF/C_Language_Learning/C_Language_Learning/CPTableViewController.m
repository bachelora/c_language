//
//  CPTableViewController.m
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/9.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "CPTableViewController.h"
#import "SectionModel.h"
#import "SectionTableViewCell.h"
#import "UIViewController+Json.h"
#import "RowTableViewController.h"


@interface CPTableViewController ()
@property(nonatomic,strong)NSArray <SectionModel*>*CPAray;
@end

@implementation CPTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *datas = (NSArray*)[self.cache objectForKey:@"datas"];
          if (datas.count) {
              self.CPAray = datas;
              [self.tableView reloadData];
          }else{
                [self.class getFrom:@"compiler.json" model:SectionModel.class completion:^(NSArray * _Nonnull array, NSError * _Nullable error) {
                                if (!error) {
                                    [self.cache setObject:array forKey:@"datas"];
                                    self.CPAray = array;
                                    [self.tableView reloadData];
                                }
                            }];
          }
    
    
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.CPAray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.titleLableee.text = self.CPAray[indexPath.row].title;
    // Configure the cell...
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    RowTableViewController *row = segue.destinationViewController;
    if ([row isKindOfClass:RowTableViewController.class]) {
        SectionModel *sec = self.CPAray[self.tableView.indexPathForSelectedRow.row];
        row.datasss = sec.array;
        row.title = sec.title;
    }
}

@end
