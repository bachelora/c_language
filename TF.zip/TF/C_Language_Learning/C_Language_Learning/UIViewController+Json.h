//
//  UIViewController+Json.h
//  C_Language_Learning
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

@import YYCache;

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (Json)

@property(nonatomic,readonly,strong)YYCache *cache;

+(void)getFrom:(NSString*)api model:(Class)class completion:(nullable void (^)(NSArray* array,  NSError * _Nullable error))completion;
@end

NS_ASSUME_NONNULL_END
