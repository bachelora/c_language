//
//  MainTableViewCell.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "MainTableViewCell.h"

@implementation MainTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
