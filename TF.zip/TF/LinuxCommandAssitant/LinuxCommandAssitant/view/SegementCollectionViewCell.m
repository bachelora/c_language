//
//  SegementCollectionViewCell.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "SegementCollectionViewCell.h"

@implementation SegementCollectionViewCell

-(void)setSelected:(BOOL)selected{
    [super setSelected:selected];
    UIColor *selectedColor = UIColor.systemBlueColor;
    
    self.bottomLine.backgroundColor = selected?selectedColor:UIColor.clearColor;
    self.title.textColor = selected?selectedColor:UIColor.blackColor;
}

@end
