//
//  HeaderView.h
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryMM.h"
NS_ASSUME_NONNULL_BEGIN

typedef void(^HeaderClick)(NSArray<CommandModel*>*);

@interface HeaderView : UIView<UICollectionViewDataSource,UICollectionViewDelegate>

@property(nonatomic,copy)HeaderClick click;

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

-(void)reloadTable;
@property(nonatomic,strong)NSArray<CategoryMM*> *categroy;

@end

NS_ASSUME_NONNULL_END
