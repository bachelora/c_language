//
//  HeaderView.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "HeaderView.h"
#import "SegementCollectionViewCell.h"

@interface HeaderView ()

@end

@implementation HeaderView

-(void)reloadTable{
    [self.collectionView reloadData];
    NSIndexPath *path = [NSIndexPath indexPathForItem:0 inSection:0];
    [self.collectionView selectItemAtIndexPath:path animated:NO scrollPosition:UICollectionViewScrollPositionNone];
    
    [self collectionView:self.collectionView didSelectItemAtIndexPath:path];
}


- (nonnull __kindof UICollectionViewCell *)collectionView:(nonnull UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    SegementCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"id" forIndexPath:indexPath];
    CategoryMM *ca = self.categroy[indexPath.row];
    NSArray <NSString*>*sts = [ca.name componentsSeparatedByString:@"、"];
    if (sts.count == 2) {
        cell.title.text = sts.lastObject;
    }else{
        cell.title.text = ca.name;
    }
    
    return cell;
}

- (NSInteger)collectionView:(nonnull UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.categroy.count;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (self.click) {
        self.click(self.categroy[indexPath.row].subs);
    }
}


@end
