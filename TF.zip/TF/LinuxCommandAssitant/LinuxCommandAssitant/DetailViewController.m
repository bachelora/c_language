//
//  DetailViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "DetailViewController.h"
#import "Button.h"
@import Masonry;

@interface DetailViewController ()
@property(nonatomic,strong)UILabel *lable;
@property(nonatomic,strong)UIView *bbbbkk;
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *refresh = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshWebView)];
    
    UIImage *normal = [UIImage systemImageNamed:@"suit.heart"];
    UIImage *select = [UIImage systemImageNamed:@"suit.heart.fill"];
    Button *btn = Button.new;
    btn.frame = CGRectMake(0, 0, 30, 25);
    btn.selected = self.command.isFavorite;
    [btn addTarget:self action:@selector(like:) forControlEvents:UIControlEventTouchUpInside];
    [btn setImage:normal forState:UIControlStateNormal];
    [btn setImage:select forState:UIControlStateSelected];
    
    UIBarButtonItem *fav = [[UIBarButtonItem alloc]initWithCustomView:btn];
    self.navigationItem.rightBarButtonItems = @[refresh,fav];
}

-(void)like:(UIButton*)btn{
    btn.selected = !btn.isSelected;
    self.command.isFavorite = btn.selected;
    [NSNotificationCenter.defaultCenter postNotificationName:@"likeChange" object:nil];
}

-(void)refreshWebView{
    [self startLoadUrl:self.webUrl];
}

-(void)loadView{
    [super loadView];
    [self.view addSubview:self.bbbbkk];
    [self.bbbbkk mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"didStartProvisionalNavigation--%@",self.webUrl);
    self.lable.text = @"loading..";
    self.bbbbkk.hidden = NO;
    webView.hidden = YES;
}

-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    self.lable.text = @"Oops..";
    self.bbbbkk.hidden = NO;
    webView.hidden = YES;
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
  
    NSLog(@"didFinishNavigation");
    
    NSString *js = @"\
     $('.container.logo-search').remove();\
     $('.container.navigation').remove();\
     $('.previous-next-links').remove();\
     $('.fixed-btn').remove();\
     $('#comments').remove();\
     $('#footer').remove();\
     $('#postcomments').remove();\
     $('a').remove();";

    [webView evaluateJavaScript:js completionHandler:^(id _Nullable a, NSError * _Nullable error) {
        NSLog(@"evaluateJavaScript--%@",error);
        self.bbbbkk.hidden = YES;
        webView.hidden = NO;
    }];//
    
}

-(UIView *)bbbbkk{
    if (!_bbbbkk) {
        _bbbbkk = UIView.new;
        _bbbbkk.backgroundColor = UIColor.whiteColor;
        self.lable = UILabel.new;
        self.lable.font = [UIFont fontWithName:@"PingFangSC-Medium" size:30];
        self.lable.text = @"Wait...";
        [_bbbbkk addSubview:self.lable];
        [self.lable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(_bbbbkk);
        }];
    }
    return _bbbbkk;
}

@end
