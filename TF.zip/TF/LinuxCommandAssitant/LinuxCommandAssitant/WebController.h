//
//  WebController.h
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
@import WebKit;
NS_ASSUME_NONNULL_BEGIN

@interface WebController : UIViewController
@property(nonatomic,strong)WKWebView *webView;
-(void)startLoadUrl:(NSString*)url;
@property(nonatomic,copy)NSString *webUrl;
@end

NS_ASSUME_NONNULL_END
