//
//  DetailViewController.h
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "WebController.h"
#import "CommandModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : WebController
@property(nonatomic,strong)CommandModel*command;
@end

NS_ASSUME_NONNULL_END
