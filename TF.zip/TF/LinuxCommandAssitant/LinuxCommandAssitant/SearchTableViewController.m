//
//  SearchTableViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "SearchTableViewController.h"
#import "DetailViewController.h"
#import "MainTableViewCell.h"

@interface SearchTableViewController ()

@end

@implementation SearchTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

#pragma mark - Table view data source


-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return self.indexs[section];
}

-(NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    return  self.indexs;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.datas.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.datas[section].count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    CommandModel *m = self.datas[indexPath.section][indexPath.row];
    // Configure the cell...
    cell.title.text = m.title;
    return cell;
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
     DetailViewController *detail = segue.destinationViewController;
       if ([detail isKindOfClass:DetailViewController.class]) {
           NSIndexPath *selecte = self.tableView.indexPathForSelectedRow;
           CommandModel *m = self.datas[selecte.section][selecte.row];
           detail.title = m.title;
           detail.webUrl = m.url;
           detail.command = m;
       }
}


@end
