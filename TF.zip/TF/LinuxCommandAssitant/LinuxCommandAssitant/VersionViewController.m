//
//  VersionViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "VersionViewController.h"

@interface VersionViewController ()
@property (weak, nonatomic) IBOutlet UILabel *versionLable;

@end

@implementation VersionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
          self.versionLable.text = version;
}

@end
