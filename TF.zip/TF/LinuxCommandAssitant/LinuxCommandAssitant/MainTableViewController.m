//
//  MainTableViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "MainTableViewController.h"
#import "CommandModel.h"
#import "MainTableViewCell.h"
#import "CategoryMM.h"
#import "HeaderView.h"
#import "DetailViewController.h"
#import "SearchTableViewController.h"

@import YYCache;

@interface MainTableViewController ()
@property(nonatomic,strong)NSArray<CategoryMM*> *alldatas;
@property(nonatomic,strong)YYCache *cache;
@property (weak, nonatomic) IBOutlet HeaderView *headerView;
@property(nonatomic,strong)NSArray <CommandModel*>*array;
@end

@implementation MainTableViewController

-(YYCache *)cache{
    if (!_cache) {
        _cache = [[YYCache alloc]initWithName:NSStringFromClass(self.class)];
    }
    return _cache;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.headerView.click = ^(NSArray* array){
        self.array = array;
        [self.tableView reloadData];
    };
    
    NSArray*arry = (NSArray*)[self.cache objectForKey:@"data"];
    if (arry.count) {
        self.alldatas = arry;
        self.headerView.categroy = arry;
        [self.headerView reloadTable];
    }else{
        [CommandModel request:@"linux.json" model:CategoryMM.class completion:^(NSArray * _Nonnull array, NSError * _Nullable error) {
            self.alldatas = array;
            if (array.count) {
                [self.cache setObject:array forKey:@"data"];
            }
            self.headerView.categroy = array;
            [self.headerView reloadTable];
        }];
    }
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(likeChange:) name:@"likeChange" object:nil];
}

-(void)likeChange:(NSNotification*)noty{
    if (self.alldatas.count) {
        [self.cache setObject:self.alldatas forKey:@"data"];
    }
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    CommandModel *com = self.array[indexPath.row];
    cell.title.text = com.title;
    return cell;
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DetailViewController *detail = segue.destinationViewController;
    if ([detail isKindOfClass:DetailViewController.class]) {
        CommandModel *m = self.array[self.tableView.indexPathForSelectedRow.row];
        detail.title = m.title;
        detail.webUrl = m.url;
        detail.command = m;
    }
    
    SearchTableViewController *search = segue.destinationViewController;
    if ([search isKindOfClass:SearchTableViewController.class]) {
        NSMutableDictionary *dict = @{}.mutableCopy;
        
        for (CategoryMM*ca in self.alldatas) {
            for (CommandModel *m in ca.subs) {
                NSString *key = [m.title substringToIndex:1];
               // NSLog(@"key:%@",key);
                NSMutableArray *arry = dict[key];
                if (![arry isKindOfClass:NSMutableArray.class]) {
                    arry = @[].mutableCopy;
                    dict[key] = arry;
                }
                [arry addObject:m];
            }
        }
       
        search.indexs = [dict.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSString* obj1, NSString* obj2) {
            return [obj1 compare:obj2 options:NSCaseInsensitiveSearch];
        }];
        
        search.datas = [dict.allValues sortedArrayUsingComparator:^NSComparisonResult(NSArray<CommandModel*>* obj1,NSArray<CommandModel*>* obj2) {
               return [obj1.firstObject.title compare:obj2.firstObject.title options:NSCaseInsensitiveSearch];
           }];
    }
}


@end
