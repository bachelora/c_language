//
//  FavoriteTableViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "FavoriteTableViewController.h"
#import "MainTableViewCell.h"
#import "CommandModel.h"
#import "MainTableViewController.h"
#import "CategoryMM.h"
#import "DetailViewController.h"
@import YYCache;

@interface FavoriteTableViewController ()
@property(nonatomic,strong)YYCache *cache;
@property(nonatomic,strong)NSArray<CommandModel*> *array;
@end

@implementation FavoriteTableViewController

-(YYCache *)cache{
    if (!_cache) {
        _cache = [[YYCache alloc]initWithName:NSStringFromClass(MainTableViewController.class)];
    }
    return _cache;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self likeChange:nil];
    
   [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(likeChange:) name:@"likeChange" object:nil];
}

-(void)likeChange:(NSNotification*)noty{
    NSArray<CategoryMM*> *cageroy = (NSArray*)[self.cache objectForKey:@"data"];
    if (cageroy.count) {
        NSMutableArray *ddd = @[].mutableCopy;
        for (CategoryMM*mm in cageroy) {
            for (CommandModel*com in mm.subs) {
                if (com.isFavorite) {
                    [ddd addObject:com];
                }
            }
        }
        self.array = ddd;
        [self.tableView reloadData];
    }
}
#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    CommandModel *m = self.array[indexPath.row];
    cell.title.text = m.title;
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
     DetailViewController *detail = segue.destinationViewController;
       if ([detail isKindOfClass:DetailViewController.class]) {
           CommandModel *m = self.array[self.tableView.indexPathForSelectedRow.row];
           detail.title = m.title;
           detail.webUrl = m.url;
           detail.command = m;
       }
}


@end
