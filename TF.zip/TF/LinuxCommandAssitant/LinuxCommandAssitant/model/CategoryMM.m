//
//  Category.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "CategoryMM.h"

@import YYModel;

@implementation CategoryMM

- (void)encodeWithCoder:(nonnull NSCoder *)coder {
    [self yy_modelEncodeWithCoder:coder];
}

- (nullable instancetype)initWithCoder:(nonnull NSCoder *)coder {
    if ([super init]) {
    }
    return [self yy_modelInitWithCoder:coder];
}


+ (NSDictionary *)modelContainerPropertyGenericClass {
    // value should be Class or Class name.
    return @{@"subs" : [CommandModel class]};
}
@end
