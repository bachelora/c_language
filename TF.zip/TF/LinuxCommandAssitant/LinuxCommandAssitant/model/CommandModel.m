//
//  CommandModel.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "CommandModel.h"

#define AAAURL (@"https://raw.githubusercontent.com/bachelora/linux_command/master/")

@import AFNetworking;
@import YYModel;

@implementation CommandModel


+(void)request:(NSString*)api model:(Class)class completion:(nullable void (^)(NSArray* array,  NSError * _Nullable error))completion{
    NSString *path = [NSString stringWithFormat:@"%@%@",AAAURL,api];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFJSONResponseSerializer *ser = AFJSONResponseSerializer.serializer;;
    ser.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = ser;
    NSURL *URL = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        NSArray *ret = nil;
        if (!error) {
           ret= [NSArray yy_modelArrayWithClass:class json:responseObject];
        }
        if (completion) {
            completion(ret,error);
        }
    }];
    [dataTask resume];
}

- (void)encodeWithCoder:(nonnull NSCoder *)coder {
    [self yy_modelEncodeWithCoder:coder];
}

- (nullable instancetype)initWithCoder:(nonnull NSCoder *)coder {
    if ([super init]) {
    }
    return [self yy_modelInitWithCoder:coder];
}

@end
