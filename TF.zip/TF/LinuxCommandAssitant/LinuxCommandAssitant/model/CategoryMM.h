//
//  Category.h
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/8.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommandModel.h"
NS_ASSUME_NONNULL_BEGIN


@interface CategoryMM : NSObject<NSCoding>

@property(nonatomic,copy)NSString *name;

@property(nonatomic,strong)NSArray<CommandModel*>*subs;

@end

NS_ASSUME_NONNULL_END
