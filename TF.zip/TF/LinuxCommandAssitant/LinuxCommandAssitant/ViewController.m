//
//  ViewController.m
//  LinuxCommandAssitant
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 mahoone. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
