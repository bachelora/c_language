//
//  DBHelper.m
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "DBHelper.h"
#import "AlgorithmModelUU.h"
#import "CategoryModel.h"
#import "RelationModel.h"

static DBHelper *__helper;

@interface DBHelper ()

@end

@implementation DBHelper

-(instancetype)init{
    if (self = [super init]) {
        NSString *lidDirPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) lastObject];
        NSString *databasePath = [lidDirPath stringByAppendingPathComponent:@"Database.sqlite"];
        NSLog(@"dbPath:%@",databasePath);
        self.dbQueue = [FMDatabaseQueue databaseQueueWithPath:databasePath];
        if (self.dbQueue != nil) {
           //NSLog(@"数据库创建成功!");
        } else {
            NSLog(@"数据库创建失败!");
        }
    }
    return self;
}


-(void)createTable{
    [AlgorithmModelUU createTable];
    [CategoryModel createTable];
    [RelationModel createTable];
}

+(instancetype)sharede{
    if (__helper) {
        return __helper;
    }
    __helper = [[DBHelper alloc]init];
    return __helper;
}


@end
