//
//  WebViewController.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "WebViewController.h"
@import WebKit;

@interface WebViewController ()<WKNavigationDelegate>
@property(nonatomic,strong)WKWebView *webView;
@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)loadView{
    self.view = self.webView;
    [self startLoad:self.url];
}

#pragma mark - delegate

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
}

-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
}

-(void)startLoad:(NSString*)path{
    self.url = path;
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:path]]];
}

-(WKWebView *)webView{
    if (!_webView) {
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc]init];
        _webView = [[WKWebView alloc]initWithFrame:UIScreen.mainScreen.bounds configuration:config];
        _webView.navigationDelegate = self;
    }
    return _webView;
}
@end
