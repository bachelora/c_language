//
//  SubTableViewController.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "SubTableViewController.h"
#import "SubTableViewCell.h"
#import "AlgorithmModelUU.h"
#import "NSObject+Helper.h"
#import "QuestionViewController.h"
#import "AlgorithmModelUU.h"
#import "RelationModel.h"

@interface SubTableViewController ()
@property(nonatomic,strong)NSArray<AlgorithmModelUU*>*models;
@end

@implementation SubTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.categoryID.length) {
        [AlgorithmModelUU quaryCategoryId:self.categoryID complete:^(NSArray * _Nonnull result) {
            if (result.count) {
                self.models = result;
                [self.tableView reloadData];
            }else{
                [self request];
            }
        }];
    }else{
        [AlgorithmModelUU selectQueryAll:^(NSArray * _Nonnull result) {
            self.title = @"Algorithm";
            if (result.count) {
                self.models = result;
                [self.tableView reloadData];
            }else{
                //[self request];
            }
        }];
    }
    
    
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refresh) name:@"SubTableViewRefresh" object:nil];
}

-(void)request{
    NSString *fullUrl = self.url;
    if (fullUrl.length == 0) {
        fullUrl = @"";
    }
    [NSObject requestJson:fullUrl modelClass:AlgorithmModelUU.class completionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
        if (!error) {
            self.models = responseObject;
            [AlgorithmModelUU insert:self.models];
            [self.tableView reloadData];
            
            NSMutableArray *relation = [NSMutableArray arrayWithCapacity:self.models.count];
            for (AlgorithmModelUU*uu in self.models) {
                RelationModel *r = [RelationModel.alloc init];
                r.algorithmiD = uu.iD;
                r.categoryiD = self.categoryID;
               NSString *ID = [NSString stringWithFormat:@"%@-%@",self.categoryID,uu.iD];
                r.iD = ID;
                [relation addObject:r];
            }
            [RelationModel insert:relation];
        }
    }];
}

-(void)refresh{
    [self.tableView reloadData];
}

-(void)dealloc{
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.models.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SubTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    AlgorithmModelUU *m = self.models[indexPath.row];
    cell.name.text = [NSString stringWithFormat:@"%@、%@",m.iD,m.title];
    cell.difficulty.text = m.difficulty;
    cell.likeimage.hidden = !m.isFavorite;
    return cell;
}




#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSIndexPath *selected = self.tableView.indexPathForSelectedRow;
    if (selected) {
        QuestionViewController *web = segue.destinationViewController;
        web.model = self.models[selected.row];
        web.url = self.models[selected.row].url;
        web.title = self.models[selected.row].title;
    }
}


//+(void)getGlobalData:(nullable void (^)(NSArray<AlgorithmModel*>*allDatas))completionHandler{
//    static NSArray<AlgorithmModel*>*globalData = nil;
//    if (globalData) {
//        if (completionHandler) {
//            completionHandler(globalData);
//        }
//        return;
//    }
//    NSObject *o = [NSObject.alloc init];
//    [o requestPlist:@"algorithm.plist" modelClass:AlgorithmModel.class completionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
//        if ([responseObject isKindOfClass:NSArray.class]) {
//            globalData = responseObject;
//        }
//        if (completionHandler) {
//            completionHandler(globalData);
//        }
//    }];
//}

@end
