//
//  QuestionViewController.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "QuestionViewController.h"
@import WebKit;
@import Masonry;
@interface QuestionViewController ()
{
    UILabel *loading;
    UIButton *likeBtn;
}
@end

@implementation QuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    likeBtn = UIButton.new;
    [likeBtn addTarget:self action:@selector(likeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [likeBtn setImage:[UIImage imageNamed:@"lsu_icon_like_normal"] forState:UIControlStateNormal];
    [likeBtn setImage:[UIImage imageNamed:@"lsn_autoPlay_liked_normal"] forState:UIControlStateSelected];
    likeBtn.selected = self.model.isFavorite;
    UIBarButtonItem *likeItem = [[UIBarButtonItem alloc]initWithCustomView:likeBtn];
    self.navigationItem.rightBarButtonItems = @[likeItem];
}

-(void)likeBtnClick:(UIButton*)sender{
    sender.selected = !sender.isSelected;
    self.model.isFavorite = sender.selected;
    [self.model update];
    [NSNotificationCenter.defaultCenter postNotificationName:@"SubTableViewRefresh" object:nil];
}

-(void)loadView{
    [super loadView];
    WKWebView *web = (WKWebView *)self.view;
    UIView *bkView = UIView.new;
    bkView.backgroundColor = UIColor.whiteColor;
    
    loading = UILabel.new;
    loading.text = @"loading...";
    loading.font = [UIFont fontWithName:@"PingFangSC-Regular" size:28];
    [bkView addSubview:loading];
    [loading mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(bkView);
    }];
    
    self.view = bkView;
    [bkView addSubview:web];
    [web mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(bkView);
    }];
}

-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    webView.hidden = YES;
    //NSLog(@"==didStartProvisionalNavigation");
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
  
    NSString *js = @"var idObject = document.getElementsByClassName('tab-view hide-scrollbar')[0].parentNode; \
    idObject.parentNode.removeChild(idObject);\
\
    idObject = document.getElementsByClassName('action-btn-base')[0];\
    idObject.parentNode.removeChild(idObject);\
\
    idObject = document.getElementsByClassName('question-detail-bottom')[0].parentNode;\
    idObject.parentNode.removeChild(idObject);\
\
    idObject = document.getElementById('desktop-side-bar');\
    idObject.parentNode.removeChild(idObject);\
\
    idObject = document.getElementById('lc-footer');\
    idObject.parentNode.removeChild(idObject);\
\
    idObject = document.getElementById('interviewed-div');\
    idObject.parentNode.removeChild(idObject);";

    [webView evaluateJavaScript:js completionHandler:^(id _Nullable a, NSError * _Nullable error) {
        webView.hidden = NO;
    }];//
}

-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    //NSLog(@"didFailNavigation-%@",error);
    loading.text  =@"Oops";
    
}

@end
