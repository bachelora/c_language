//
//  NSObject+Helper.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/28.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "NSObject+Helper.h"

@import AFNetworking;
@import YYModel;

#define kBaseURL (@"https://raw.githubusercontent.com/bachelora/algorithm/master/")
#define kFullPath(api) ([NSString stringWithFormat:@"%@%@",kBaseURL,api])

@implementation NSObject (Helper)

-(void)requestJson:(NSString*)api modelClass:(Class)cls completionHandler:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler{
    NSURL *URL = [NSURL URLWithString:(api)];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFJSONResponseSerializer*plist = AFJSONResponseSerializer.serializer;
    plist.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = plist;
    
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id responseObject, NSError * _Nullable error) {
        NSArray*ret = nil;
        if (!error) {
            ret = [NSArray yy_modelArrayWithClass:cls json:responseObject];
        }
        if (completionHandler) {
            completionHandler(ret,error);
        }
    }];
    [dataTask resume];
}

-(void)requestPlist:(NSString*)api modelClass:(Class)cls completionHandler:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler{
    NSURL *URL = [NSURL URLWithString:kFullPath(api)];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFPropertyListResponseSerializer*plist = AFPropertyListResponseSerializer.serializer;
    plist.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = plist;
    
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id responseObject, NSError * _Nullable error) {
        NSArray*ret = nil;
        if (!error) {
            ret = [NSArray yy_modelArrayWithClass:cls json:responseObject];
        }
        if (completionHandler) {
            completionHandler(ret,error);
        }
    }];
    [dataTask resume];
}

@end
