//
//  MEEETableViewController.m
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/6.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "MEEETableViewController.h"

@interface MEEETableViewController ()
@property (weak, nonatomic) IBOutlet UILabel *versionLable;

@end

@implementation MEEETableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    self.versionLable.text = version;
}


@end
