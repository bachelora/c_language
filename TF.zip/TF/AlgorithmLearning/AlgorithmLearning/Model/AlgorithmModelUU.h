//
//  AlgorithmModelUU.h
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DBObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface AlgorithmModelUU : DBObject

+(void)quaryCategoryId:(NSString*)categoryID complete:(void (^)(NSArray*result))block;

@property(nonatomic,copy)NSString *acceptance;
@property(nonatomic,copy)NSString *difficulty;
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *url;
@property(nonatomic,copy)NSString<DBPrimaryKey> *iD;

@property(nonatomic,assign)BOOL  isFavorite;
@end

NS_ASSUME_NONNULL_END
