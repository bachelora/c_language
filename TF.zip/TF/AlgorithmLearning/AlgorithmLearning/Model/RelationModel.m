//
//  RelationModel.m
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "RelationModel.h"


@implementation RelationModel

@end
