//
//  DBObject.m
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "DBObject.h"
#import <objc/runtime.h>

@implementation DBObject

-(void)update{
    [DBHelper.sharede.dbQueue inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        NSString *sql = self.replaceSql;
        BOOL result = [db executeUpdate:sql];
        if (!result) {
            NSLog(@"-%s-executeUpdate-failed--sql:%@",__FILE__,sql);
            *rollback = YES;
            return;
        }
    }];
}

+(void)queryWhere:(NSString*)where complete:(void (^)(NSArray*result))block{
    [DBHelper.sharede.dbQueue inDatabase:^(FMDatabase *db) {
           NSMutableArray *array = @[].mutableCopy;
        NSMutableString *sql = [NSString stringWithFormat:@"select * from %@",NSStringFromClass(self.class)].mutableCopy;
        if (where.length) {
            [sql appendFormat:@" where %@",where];
        }
           FMResultSet *rs = [db executeQuery:sql];
           
           while ([rs next]) {
               id obj = [[self class].alloc init];
               
               unsigned int count;
               objc_property_t *propertyList = class_copyPropertyList([self class], &count);
                  
               for (unsigned int i=0; i<count; i++) {
                   NSString *propertyName = [NSString stringWithCString:property_getName(propertyList[i]) encoding:NSUTF8StringEncoding];
                   NSString *value = [rs stringForColumn:propertyName];
                   [obj setValue:value forKey:propertyName];
               }
               free(propertyList);
               
               [array addObject:obj];
           }
           
           if (block) {
               block(array);
           }
       }];
}

+(void)selectQueryAll:(void (^)(NSArray*result))block{
    [self queryWhere:nil complete:block];
}

+(void)insert:(NSArray<DBObject*>*)array{
    
    [DBHelper.sharede.dbQueue inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {

        for (DBObject *obj in array) {
            NSString *sql = obj.replaceSql;
            BOOL result = [db executeUpdate:sql];
            if (!result) {
                NSLog(@"-%s-executeUpdate-failed--sql:%@",__FILE__,sql);
                *rollback = YES;
                return;
            }
        }
    }];
}



+(void)createTable{
    DBHelper *helper = DBHelper.sharede;
    NSString *table = NSStringFromClass(self.class);
    NSMutableString *sql = [NSMutableString stringWithFormat:@"create table if not exists %@(",table];
    unsigned int count;
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for (unsigned int i=0; i<count; i++) {
        const char *propertyName = property_getName(propertyList[i]);
        NSString * propertyType = [NSString stringWithCString:property_getAttributes(propertyList[i]) encoding:NSUTF8StringEncoding];
        [sql appendFormat:@"%s text not null ",propertyName];
        if ([propertyType containsString:@"<DBPrimaryKey>"]) {
            [sql appendFormat:@"PRIMARY KEY,"];
        }else{
            [sql appendFormat:@","];
        }
       // NSLog(@"prop=>%s      %@", propertyName,propertyType);
    }
    free(propertyList);
    [sql deleteCharactersInRange:NSMakeRange(sql.length-1, 1)];
    [sql appendString:@");"];
   // NSLog(@"sql====%@",sql);
    [helper.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
        if ([db open]) {
            BOOL result = [db executeUpdate:sql];
            if (result) {
               // NSLog(@"创建表成功");
            } else {
                NSLog(@"创建表失败");
            }
            [db close];
        }
    }];
}


-(NSString*)replaceSql{
    NSString *table = NSStringFromClass(self.class);
    NSMutableString *sql = [NSMutableString stringWithFormat:@"replace INTO %@ ",table];
    NSMutableString *name = [NSMutableString stringWithString:@"("];
    NSMutableString *values = [NSMutableString stringWithString:@"("];
    
    unsigned int count;
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for (unsigned int i=0; i<count; i++) {
        NSString * propertyName = [NSString stringWithCString:property_getName(propertyList[i]) encoding:NSUTF8StringEncoding];
        [name appendFormat:@"%@",propertyName];
        id v = [self valueForKey:propertyName];
        if (v && ![v isKindOfClass:NSNull.class]) {
            NSString*str = [NSString stringWithFormat:@"%@",v];
            [values appendFormat:@"'%@'",[str stringByReplacingOccurrencesOfString:@"'" withString:@"''"]];
        }
        if (i != count-1) {
            [name appendString:@","];
            [values appendString:@","];
        }
    }
    free(propertyList);
    
    [sql appendFormat:@"%@) VALUES %@);",name,values];
    return sql;
}
@end
