//
//  AlgorithmModelUU.m
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "AlgorithmModelUU.h"
#import <objc/runtime.h>
#import "RelationModel.h"

@implementation AlgorithmModelUU

+(void)quaryCategoryId:(NSString*)categoryID complete:(void (^)(NSArray*result))block{
    NSString *sql = [NSString stringWithFormat:@"select * from  %@ a LEFT JOIN %@ b on a.algorithmiD=b.iD WHERE a.categoryiD=%@",NSStringFromClass(RelationModel.class),NSStringFromClass(self.class),categoryID];
    
    [DBHelper.sharede.dbQueue inDatabase:^(FMDatabase *db) {
           NSMutableArray *array = @[].mutableCopy;
           FMResultSet *rs = [db executeQuery:sql];
           
           while ([rs next]) {
               id obj = [[self class].alloc init];
               
               unsigned int count;
               objc_property_t *propertyList = class_copyPropertyList([self class], &count);
                  
               for (unsigned int i=0; i<count; i++) {
                   NSString *propertyName = [NSString stringWithCString:property_getName(propertyList[i]) encoding:NSUTF8StringEncoding];
                   NSString *value = [rs stringForColumn:propertyName];
                   [obj setValue:value forKey:propertyName];
               }
               free(propertyList);
               
               [array addObject:obj];
           }
           
           if (block) {
               block(array);
           }
       }];
}

@end
