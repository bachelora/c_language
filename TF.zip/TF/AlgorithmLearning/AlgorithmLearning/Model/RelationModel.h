//
//  RelationModel.h
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DBObject.h"
NS_ASSUME_NONNULL_BEGIN

@interface RelationModel : DBObject

@property(nonatomic,copy)NSString<DBPrimaryKey> *iD;
@property(nonatomic,copy)NSString * categoryiD;
@property(nonatomic,copy)NSString * algorithmiD;
@end

NS_ASSUME_NONNULL_END
