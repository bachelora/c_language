//
//  DBObject.h
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DBHelper.h"
NS_ASSUME_NONNULL_BEGIN

@protocol DBPrimaryKey <NSObject>
@end

@interface DBObject : NSObject

-(void)update;
+(void)queryWhere:(NSString*)where complete:(void (^)(NSArray*result))block;
+(void)selectQueryAll:(void (^)(NSArray*result))block;

+(void)insert:(NSArray<DBObject*>*)array;

-(NSString*)replaceSql;

+(void)createTable;
@end

NS_ASSUME_NONNULL_END
