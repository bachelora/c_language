//
//  SubTableViewCell.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "SubTableViewCell.h"

@implementation SubTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
