//
//  SubTableViewController.h
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlgorithmModelUU.h"
NS_ASSUME_NONNULL_BEGIN

@interface SubTableViewController : UITableViewController

@property(nonatomic,copy)NSString *categoryID;

@property(nonatomic,copy)NSString *url;

//+(void)getGlobalData:(nullable void (^)(NSArray<AlgorithmModel*>*allDatas))completionHandler;

@end

NS_ASSUME_NONNULL_END
