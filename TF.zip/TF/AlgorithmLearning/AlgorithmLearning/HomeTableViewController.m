//
//  HomeTableViewController.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/28.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "HomeTableViewController.h"
#import "CategoryModel.h"
#import "HomeTableViewCell.h"
#import "NSObject+Helper.h"
#import "SubTableViewController.h"

@interface HomeTableViewController ()
@property(nonatomic,strong)NSArray <CategoryModel*>*data;
@end

@implementation HomeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [CategoryModel selectQueryAll:^(NSArray * _Nonnull result) {
        if (result.count) {
            self.data = result;
            [self.tableView reloadData];
        }else{
            [self request];
        }
    }];
    
}

#pragma mark - Table view data source

-(void)request{
    [self requestPlist:@"category.plist" modelClass:CategoryModel.class completionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
        
        if (!error) {
            self.data = responseObject;
            [CategoryModel insert:self.data];
            [self.tableView reloadData];
        }
    }];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.data.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    CategoryModel *m = self.data[indexPath.row];
    cell.name.text = [NSString stringWithFormat:@"%@、%@",m.iD,m.title];
    cell.count.text = @(m.total).stringValue;
    return cell;
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    SubTableViewController *des = segue.destinationViewController;;
    NSIndexPath* selected = self.tableView.indexPathForSelectedRow;
    if (selected && [des isKindOfClass:SubTableViewController.class]) {
        CategoryModel *m = self.data[selected.row];
        des.title = m.title;
        des.categoryID = m.iD;
        des.url = m.url;
    }
}


@end
