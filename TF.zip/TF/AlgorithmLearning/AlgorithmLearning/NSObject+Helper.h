//
//  NSObject+Helper.h
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/28.
//  Copyright © 2020 Mahoone. All rights reserved.



#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (Helper)

-(void)requestJson:(NSString*)api modelClass:(Class)cls completionHandler:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler;


-(void)requestPlist:(NSString*)api modelClass:(Class)cls completionHandler:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler;
@end

NS_ASSUME_NONNULL_END
