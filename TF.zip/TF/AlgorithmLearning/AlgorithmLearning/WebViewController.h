//
//  WebViewController.h
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WebViewController : UIViewController

-(void)startLoad:(NSString*)path;
@property(nonatomic,copy)NSString *url;
@end

NS_ASSUME_NONNULL_END
