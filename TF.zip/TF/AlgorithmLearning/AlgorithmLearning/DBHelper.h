//
//  DBHelper.h
//  AlgorithmLearning
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>
@import FMDB;
NS_ASSUME_NONNULL_BEGIN

@interface DBHelper : NSObject
@property(nonatomic,strong)FMDatabaseQueue *dbQueue;
+(instancetype)sharede;

-(void)createTable;
@end

NS_ASSUME_NONNULL_END
