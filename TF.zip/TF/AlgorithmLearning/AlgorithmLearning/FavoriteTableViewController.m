//
//  FavoriteTableViewController.m
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/28.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "FavoriteTableViewController.h"
#import "SubTableViewController.h"
#import "SubTableViewCell.h"
#import "QuestionViewController.h"

@import Masonry;

@interface FavoriteTableViewController ()
@property(nonatomic,strong)UIView *emptyView;
@property(nonatomic,strong)NSArray <AlgorithmModelUU*>*datas;
@end

@implementation FavoriteTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

#pragma mark - Table view data source

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    [AlgorithmModelUU queryWhere:@"isFavorite = 1" complete:^(NSArray * _Nonnull result) {
        if (result.count) {
            self.datas = result;
            [self.tableView reloadData];
        }
    }];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    tableView.backgroundView = self.datas.count?nil:self.emptyView;
    return self.datas.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SubTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
     AlgorithmModelUU *m = self.datas[indexPath.row];
     cell.name.text = [NSString stringWithFormat:@"%@、%@",m.iD,m.title];
     cell.difficulty.text = m.difficulty;
     cell.likeimage.hidden = !m.isFavorite;
    return cell;
}



- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSIndexPath *selected = self.tableView.indexPathForSelectedRow;
    if (selected) {
        QuestionViewController *web = segue.destinationViewController;
        web.model = self.datas[selected.row];
        web.url = self.datas[selected.row].url;
        web.title = self.datas[selected.row].title;
    }
}

-(UIView *)emptyView{
    if (!_emptyView) {
        _emptyView = [UIView.alloc initWithFrame:UIScreen.mainScreen.bounds];;
        _emptyView.backgroundColor = UIColor.clearColor;
        UILabel *lable = UILabel.new;
        lable.font = [UIFont fontWithName:@"PingFangSC-Regular" size:30];
        lable.textColor = UIColor.separatorColor;
        lable.text = @"Empty Now";
        [_emptyView addSubview:lable];
        [lable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(_emptyView);
        }];
    }
    return _emptyView;
}


@end
