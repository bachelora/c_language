//
//  QuestionViewController.h
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/29.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "WebViewController.h"
#import "AlgorithmModelUU.h"
NS_ASSUME_NONNULL_BEGIN

@interface QuestionViewController : WebViewController
@property(nonatomic,strong)AlgorithmModelUU *model;
@end

NS_ASSUME_NONNULL_END
