//
//  FavoriteTableViewController.h
//  AlgorithmLearning
//
//  Created by Mahoone on 2020/7/28.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FavoriteTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
