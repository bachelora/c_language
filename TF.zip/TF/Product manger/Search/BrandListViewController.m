//
//  BrandViewController.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "BrandListViewController.h"
#import "BrandModel.h"
#import "BrandTableViewCell.h"
#import "BrandEditViewController.h"

@import YYModel;
@import SDWebImage;
@import YYCache;

@interface BrandListViewController (){
    //YYCache *cahe;
}
@property(nonatomic,strong)YYCache *cache;
@property(nonatomic,strong)NSMutableArray<BrandModel*>*datas;
@end

@implementation BrandListViewController
-(YYCache *)cache{

    if (!_cache) {
        _cache = [[YYCache alloc]initWithName:@"brand"];
        _cache.memoryCache.shouldRemoveAllObjectsOnMemoryWarning = YES;
    }
    return _cache;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.datas = [self.cache objectForKey:@"b"];
    if (self.datas.count == 0) {
        [self load:@"brand.plist" class:BrandModel.class completion:^(NSArray* responseObject, NSError * _Nullable error) {
               if (!error) {
                   [self.cache setObject:responseObject forKey:@"b"];
                   self.datas = responseObject.mutableCopy;
                   [self.tableView reloadData];
               }
           }];
    }
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(brandSave:) name:@"brand_save" object:nil];
}



-(void)brandSave:(NSNotification*)notify{
    NSDictionary *dict = notify.userInfo;
    if (dict) {
        BrandModel *brand = dict[@"model"];
        if (brand) {
            [self.datas addObject:brand];
        }
    }
    [self.cache setObject:self.datas forKey:@"b"];
    [self.tableView reloadData];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.datas.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BrandTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    BrandModel *m = self.datas[indexPath.row];
    cell.name.text  = m.name;
    cell.details.text = m.detail;
    [cell.image sd_setImageWithURL:[NSURL URLWithString:m.imageUrl]];
    return cell;
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.datas removeObjectAtIndex:indexPath.row];
        [self brandSave:nil];
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    BrandEditViewController *edit = segue.destinationViewController;
    edit.title = segue.identifier;
    
    if ([segue.identifier isEqualToString:@"edit"]){
        NSIndexPath*select = self.tableView.indexPathForSelectedRow;
        edit.model = self.datas[select.row];
    }
}



@end
