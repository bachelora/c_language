//
//  ProductDetailViewController.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "ProductDetailViewController.h"
#import "PicButton.h"
@import SDWebImage;
@import TZImagePickerController;

@interface ProductDetailViewController (){
    UIImage *_selectedImage;
}
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *price;
@property (weak, nonatomic) IBOutlet PicButton *btnPic;
@property (weak, nonatomic) IBOutlet UITextView *feature;
@property (weak, nonatomic) IBOutlet UITextField *brand;

@end

@implementation ProductDetailViewController

- (IBAction)btnClick:(id)sender {
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 delegate:nil];
       imagePickerVc.allowTakeVideo = NO;
       imagePickerVc.allowPickingVideo = NO;
       imagePickerVc.allowPickingGif = NO;
       imagePickerVc.allowPickingOriginalPhoto = NO;
       [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
           UIImage *ig = photos.firstObject;
           self->_selectedImage = ig;
           [self.btnPic setImage:ig forState:UIControlStateNormal];

       }];
       [self presentViewController:imagePickerVc animated:YES completion:nil];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.feature.clipsToBounds = YES;
    self.feature.layer.cornerRadius = 3;
    self.feature.layer.borderColor = [UIColor.darkGrayColor colorWithAlphaComponent:0.27].CGColor;
    self.feature.layer.borderWidth = 1;
    
    [self updateUi];
}

-(void)updateUi{
    if (!self.model) {
        return;
    }
    self.name.text = self.model.title;
    self.brand.text = self.model.brand;
    self.price.text = self.model.price;
    self.feature.text = self.model.feature;
    [self.btnPic sd_setImageWithURL:[NSURL URLWithString:self.model.imageUrl] forState:UIControlStateNormal];
}


- (IBAction)save:(id)sender {
    if (self.name.text.length == 0) {
        return;
    }
    if (self.price.text.length == 0) {
        return;
    }
    if (self.brand.text.length == 0) {
        return;
    }
    if ([self.title isEqualToString:@"add"] && !_selectedImage) {
        return;
    }
    
    if (!self.model) {
        self.model = ProductModel.new;
        self.model.imageUrl = [NSString stringWithFormat:@"localhost://img%f.png",NSDate.now.timeIntervalSince1970];
    }
    self.model.title = self.name.text;
    self.model.price = self.price.text;
    self.model.brand = self.brand.text;
    self.model.feature = self.feature.text;
    
    if (_selectedImage) {
        SDImageCache *cache = SDImageCache.sharedImageCache;
        [cache storeImage:_selectedImage forKey:self.model.imageUrl completion:^{
            NSDictionary *userinfo = [self.title isEqualToString:@"add"]?@{@"model":self.model}:nil;
            [NSNotificationCenter.defaultCenter postNotificationName:@"product_save" object:nil userInfo:userinfo];
            [self.navigationController popViewControllerAnimated:YES];
        }];
        return;
    }
    NSDictionary *userinfo = [self.title isEqualToString:@"add"]?@{@"model":self.model}:nil;
    [NSNotificationCenter.defaultCenter postNotificationName:@"product_save" object:nil userInfo:userinfo];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
