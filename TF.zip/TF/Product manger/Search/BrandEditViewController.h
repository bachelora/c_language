//
//  BrandEditViewController.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BrandModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface BrandEditViewController : UIViewController
@property(nonatomic,strong)BrandModel*model;
@end

NS_ASSUME_NONNULL_END
