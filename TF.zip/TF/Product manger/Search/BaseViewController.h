//
//  BaseViewController.h
//  Search
//
//  Created by Mahoone on 2020/8/5.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UITableViewController
-(void)load:(NSString*)api class:(Class)cls completion:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler;
@end

NS_ASSUME_NONNULL_END
