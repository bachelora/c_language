//
//  PorductListViewController.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "PorductListViewController.h"
#import "ProductTableViewCell.h"
#import "ProductModel.h"
#import "ProductDetailViewController.h"

@import YYModel;
@import SDWebImage;
@import YYCache;
@interface PorductListViewController ()
@property(nonatomic,strong)YYCache *cache;
@property(nonatomic,strong)NSMutableArray<ProductModel*>*products;
@end

@implementation PorductListViewController

-(YYCache *)cache{

    if (!_cache) {
        _cache = [[YYCache alloc]initWithName:@"product"];
        _cache.memoryCache.shouldRemoveAllObjectsOnMemoryWarning = YES;
    }
    return _cache;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.products = [self.cache objectForKey:@"b0"];
    if (self.products.count == 0) {
        [self load:@"product.plist" class:ProductModel.class completion:^(NSArray* responseObject, NSError * _Nullable error) {
               if (!error) {
                   [self.cache setObject:responseObject forKey:@"b0"];
                   self.products = responseObject.mutableCopy;
                   [self.tableView reloadData];
               }
           }];
    }
    
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(productSave:) name:@"product_save" object:nil];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)productSave:(NSNotification*)notify{
    NSDictionary *dict = notify.userInfo;
    if (dict) {
        ProductModel *produt = dict[@"model"];
        if (produt) {
            [self.products addObject:produt];
        }
    }
    [self.cache setObject:self.products  forKey:@"b0"];
    [self.tableView reloadData];

}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.products.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id" forIndexPath:indexPath];
    ProductModel *p = self.products[indexPath.row];
    cell.brand.text = p.brand;
    cell.title.text = p.title;
    cell.price.text = [NSString stringWithFormat:@"$%@",p.price];
    [cell.image sd_setImageWithURL:[NSURL URLWithString:p.imageUrl]];
    
    return cell;
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.products removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self productSave:nil];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ProductDetailViewController *detail = segue.destinationViewController;
    detail.title = segue.identifier;
    
    if ([segue.identifier isEqualToString:@"edit"]){
        NSIndexPath*select = self.tableView.indexPathForSelectedRow;
        detail.model = self.products[select.row];
    }
}


@end
