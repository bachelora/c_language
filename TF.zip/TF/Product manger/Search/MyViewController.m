//
//  MyViewController.m
//  Search
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "MyViewController.h"

@interface MyViewController ()

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    self.version.text = version;
}


@end
