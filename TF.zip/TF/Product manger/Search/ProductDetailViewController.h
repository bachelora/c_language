//
//  ProductDetailViewController.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ProductDetailViewController : UIViewController
@property(nonatomic,strong)ProductModel *model;
@end

NS_ASSUME_NONNULL_END
