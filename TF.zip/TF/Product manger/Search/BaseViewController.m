//
//  BaseViewController.m
//  Search
//
//  Created by Mahoone on 2020/8/5.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "BaseViewController.h"

@import AFNetworking;
@import YYModel;

@interface BaseViewController ()

@end

@implementation BaseViewController


-(void)load:(NSString*)api class:(Class)cls completion:(nullable void (^)(id responseObject,  NSError * _Nullable error))completionHandler{
    NSString *str = [NSString stringWithFormat:@"https://raw.githubusercontent.com/bachelora/phoneChoose/master/%@",api];
    NSURL *URL = [NSURL URLWithString:str];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    AFPropertyListResponseSerializer*plist = AFPropertyListResponseSerializer.serializer;
    plist.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
    manager.responseSerializer = plist;
    
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id responseObject, NSError * _Nullable error) {
        NSArray*ret = nil;
        if (!error) {
            ret = [NSArray yy_modelArrayWithClass:cls json:responseObject];
        }
        if (completionHandler) {
            completionHandler(ret,error);
        }
    }];
    [dataTask resume];
}


@end
