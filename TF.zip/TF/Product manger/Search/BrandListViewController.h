//
//  BrandViewController.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BrandListViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
