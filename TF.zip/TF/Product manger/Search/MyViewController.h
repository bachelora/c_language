//
//  MyViewController.h
//  Search
//
//  Created by mahoone on 2020/8/7.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *version;

@end

NS_ASSUME_NONNULL_END
