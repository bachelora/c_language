//
//  BrandModel.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "BrandModel.h"

@implementation BrandModel

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.websiteUrl forKey:@"websiteUrl"];
    [aCoder encodeObject:self.detail forKey:@"detail"];
    [aCoder encodeObject:self.imageUrl forKey:@"imageUrl"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self.name = [aDecoder decodeObjectForKey:@"name"];
    self.websiteUrl = [aDecoder decodeObjectForKey:@"websiteUrl"];
    self.detail = [aDecoder decodeObjectForKey:@"detail"];
    self.imageUrl = [aDecoder decodeObjectForKey:@"imageUrl"];
    return self;
}

@end
