//
//  ProductModel.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "ProductModel.h"

@implementation ProductModel

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.title forKey:@"title"];
    
    [aCoder encodeObject:self.imageUrl forKey:@"imageUrl"];
    [aCoder encodeObject:self.feature forKey:@"feature"];
    [aCoder encodeObject:self.price forKey:@"price"];
    [aCoder encodeObject:self.brand forKey:@"brand"];
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self.title = [aDecoder decodeObjectForKey:@"title"];
    
    self.imageUrl = [aDecoder decodeObjectForKey:@"imageUrl"];
    self.feature = [aDecoder decodeObjectForKey:@"feature"];
    self.price = [aDecoder decodeObjectForKey:@"price"];
    self.brand = [aDecoder decodeObjectForKey:@"brand"];
    return self;
}

@end
