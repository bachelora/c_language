//
//  BrandModel.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BrandModel : NSObject<NSCoding>

@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *websiteUrl;
@property(nonatomic,copy)NSString *detail;
@property(nonatomic,copy)NSString *imageUrl;

@end

NS_ASSUME_NONNULL_END
