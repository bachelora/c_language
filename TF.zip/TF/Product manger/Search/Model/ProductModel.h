//
//  ProductModel.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProductModel : NSObject<NSCoding>

@property(nonatomic,copy)NSString *title;

@property(nonatomic,copy)NSString *imageUrl;
@property(nonatomic,copy)NSString *feature;

@property(nonatomic,copy)NSString *price;


@property(nonatomic,copy)NSString *brand;

@end

NS_ASSUME_NONNULL_END
