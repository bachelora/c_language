//
//  BrandEditViewController.m
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import "BrandEditViewController.h"
#import "PicButton.h"

@import SDWebImage;
@import TZImagePickerController;

@interface BrandEditViewController ()
{
    UIImage *_selectedImage;
}
@property (weak, nonatomic) IBOutlet UITextField *brandName;
@property (weak, nonatomic) IBOutlet PicButton *brandPicBtn;
@property (weak, nonatomic) IBOutlet UITextField *website;

@property (weak, nonatomic) IBOutlet UITextView *detail;
@end

@implementation BrandEditViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    self.detail.clipsToBounds = YES;
    self.detail.layer.cornerRadius = 3;
    self.detail.layer.borderColor = [UIColor.darkGrayColor colorWithAlphaComponent:0.27].CGColor;
    self.detail.layer.borderWidth = 1;
    [self.brandPicBtn addTarget:self action:@selector(picSelect) forControlEvents:UIControlEventTouchUpInside];
    [self refreshUI];
}

-(void)picSelect{
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 delegate:nil];
    imagePickerVc.allowTakeVideo = NO;
    imagePickerVc.allowPickingVideo = NO;
    imagePickerVc.allowPickingGif = NO;
    imagePickerVc.allowPickingOriginalPhoto = NO;
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        UIImage *ig = photos.firstObject;
        self->_selectedImage = ig;
        [self.brandPicBtn setImage:ig forState:UIControlStateNormal];

    }];
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}

-(void)refreshUI{
    if (!self.model) {
        return;
    }
    self.brandName.text = self.model.name;
    [self.brandPicBtn sd_setImageWithURL:[NSURL URLWithString:self.model.imageUrl] forState:UIControlStateNormal];
//    [self.brandPicBtn setImage:[UIImage imageNamed:self.model.imageUrl] forState:UIControlStateNormal];
    self.website.text = self.model.websiteUrl;
    self.detail.text = self.model.detail;
}

- (IBAction)saveClick:(id)sender {
    if (self.brandName.text.length <= 0) {
        return;
    }
    if (![self.title isEqualToString:@"edit"] && !_selectedImage) {
        return;
    }
    
    if (!self.model) {
        self.model = [BrandModel.alloc init];
        self.model.imageUrl = [NSString stringWithFormat:@"localhost://img%f.png",NSDate.now.timeIntervalSince1970];
    }
    self.model.name = self.brandName.text;
    self.model.websiteUrl = self.website.text;
    self.model.detail = self.detail.text;
    
    SDWebImageNoParamsBlock block = ^(){
        NSDictionary *userinfo = [self.title isEqualToString:@"add"]?@{@"model":self.model}:nil;
        [NSNotificationCenter.defaultCenter postNotificationName:@"brand_save" object:nil userInfo:userinfo];
        [self.navigationController popViewControllerAnimated:YES];
    };
    
    if (_selectedImage) {
        SDImageCache *cache = SDImageCache.sharedImageCache;
        [cache storeImage:_selectedImage forKey:self.model.imageUrl completion:block];
        return;
    }
    
    block();
}





@end
