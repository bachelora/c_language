//
//  ProductTableViewCell.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProductTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *brand;

@end

NS_ASSUME_NONNULL_END
