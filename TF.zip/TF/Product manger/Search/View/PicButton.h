//
//  PicButton.h
//  Search
//
//  Created by Mahoone on 2020/7/25.
//  Copyright © 2020 Mahoone. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PicButton : UIButton

@end

NS_ASSUME_NONNULL_END
